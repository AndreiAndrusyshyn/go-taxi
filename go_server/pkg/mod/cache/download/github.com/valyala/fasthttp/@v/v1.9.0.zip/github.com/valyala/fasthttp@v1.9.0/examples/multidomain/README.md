# Multidomain using SSL certs example

* Prints two messages depending on visited host.

# How to build

```
make
```

# How to run

```
./multidomain
```
